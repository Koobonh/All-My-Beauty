package com.amb.mypro.domain;

public class boardVO {
	
}
