package com.amb.bcomment.controller;


//@Controller
public class BCommentController {
	
}
